<php?>
<footer class="footer">
    <div class="footer_container">
        <div class="footer_container_item">
            <div class="footer_menu">
                <div class="menu_items"> <a href="">Главная </a> </div>
                <div class="menu_items"> <a href="">Расписание </a> </div>
                <div class="menu_items"> <a href="">Моя траектория </a> </div>
            </div>
        </div>
        <div class="footer_container_item">
            <div class="footer_logo">
                <img src="images/logo.png" width="400px" height="90px">
            </div>
        </div>
        <div class="footer_container_item">
            <div class="contacts_container">
                <div class="contacts">
                    <div class="contact">г.Брянск, ул.Молодой гвардии, 12</div>
                    <div class="contact">+7(900)301-52-18</div>
                </div>

                <div class="social">
                    <div class="social_items"> <a href="https://vk.com/kltvn" target="_blank"> <i class="fab fa-vk"></i> </a> </div>
                    <div class="social_items"> <a href="https://vk.com/kltvn" target="_blank"> <i class="fab fa-telegram"></i> </a> </div>
                    <div class="social_items"> <a href="https://vk.com/kltvn" target="_blank"> <i class="fab fa-odnoklassniki"></i> </a> </div>
                    <div class="social_items"> <a href="https://www.instagram.com/a.kltvn/" target="_blank"> <i class="fab fa-instagram"> </i> </a> </div>
                    <div class="social_items"> <a href="https://www.facebook.com/profile.php?id=100057889987517" target="_blank"> <i class="fab fa-facebook-f"></i> </a> </div>
                </div>
            </div>
        </div>
    </div>
</footer>
    <?php wp_footer(); ?>
</body>
</html>