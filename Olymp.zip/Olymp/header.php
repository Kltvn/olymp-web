<?php ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="style.css"/>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Cantata+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,700;1,300&display=swap" rel="stylesheet">
<title> Olymp </title>
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<header class="header">
    <div class="header_container">
        <div class="header_logo">
            <img src="images/logo2.png" width="150px" height="45px">
        </div>
        <nav class="header_navigation">
		    <a class="nav_button" href="http://expertsystem/contracts.php"> Главная </a>
            <a class="nav_button" href="http://expertsystem/contracts.php"> Пример </a>
            <a class="nav_button" href="http://expertsystem/contracts.php"> Пример </a>
            <a class="nav_button" href="http://expertsystem/contracts.php"> Пример </a>
            <a class="nav_button" href="http://expertsystem/contracts.php"> Пример </a>
	    </nav>
        <div class="header_account">
            <div class="account_button">
                <a href="https://vk.com/kltvn" target="_blank"> <i class="fa fa-user"></i> </a>
            </div>
        </div>
    </div>
</header>


<!-- <?php wp_head(); ?>
</head>    
<body <?php body_class(); ?>>
    <header class="header" id="header">
        <div class="header_items">
            <div class="logo_img" href="#">
                <a href="file:///D:/Учеба/3%20курс/WEB-программирование/Сайт/autoPRO.html">
                <?php the_custom_logo(); ?>
                </a>
            </div> -->