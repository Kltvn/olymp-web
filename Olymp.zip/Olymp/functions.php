<?php
// Добавление стилей и скриптов
add_action('wp_enqueue_scripts', 'olymp_styles');
function olymp_styles(){
    wp_enqueue_style('olymp', get_template_directory_uri() . '/css/style.css');
	/* wp_enqueue_script( 'autoprojs', get_template_directory_uri() . '/js/autoprojs.js', array(), '1.0.0', true ); */
}

// Добавление логотипа сайта
/* add_action('after_setup_theme', 'logo_setup');
function logo_setup(){
	add_theme_support('custom-logo', array(
        'height' => 100,
        'width'  => 250)
	);
	add_theme_support('post-thumbnails', array('engine'));
} */
// Создание записи "Расписание" 

?>