<?php get_header(); ?>
<?php the_content(); ?>
<div class="page_container">
    <div class="page_container_item">
        <img src="images/banner1.png" width="1200px" height="450px">
    </div>
    <div class="page_container_participate">
        <div class="participate_qualities_container">
            <div class="participate_quality">
                <img src="images/ban2.png" width="390px" height="230px">
            </div>
            <div class="participate_quality">
                <img src="images/ban3.png" width="390px" height="230px">
            </div>
            <div class="participate_quality">
                <img src="images/ban4.png" width="390px" height="230px">
            </div>
        </div>
        <div class="participate_button_container">
            <div class="participate_button">
                <a href=""> УЧАСТВОВАТЬ </a>
            </div>
        </div>
    </div>
    <div class="page_container_item">
        <img src="images/ban5.png" width="1200px" height="450px">
    </div>
    <div class="page_container_item">
        <img src="images/ban6.png" width="1200px" height="450px">
    </div>
    <div class="page_container_item">
        <div class="calculators_container">
            <div class="page_calculator_item">
                <img src="images/ban7.png" width="595px" height="450px">
            </div>
            <div class="page_calculator_item">
                <img src="images/ban8.png" width="595px" height="450px">
            </div>
        </div>
    </div>
    <div class="page_container_item">
        <img src="images/ban9.png" width="1200px" height="450px">
    </div>
</div>
<?php get_footer(); ?>
<div class="copyright">© 2022 Olymp by kltvn</div>